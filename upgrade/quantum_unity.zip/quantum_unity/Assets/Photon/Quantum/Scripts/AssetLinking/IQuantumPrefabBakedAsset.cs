﻿/// <summary>
/// 
/// </summary>
public interface IQuantumPrefabBakedAsset {
  void Import(QuantumPrefabAsset prefab, IQuantumPrefabNestedAsset asset);
}